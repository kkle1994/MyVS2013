﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using System.Configuration.Assemblies;
using System.Configuration.Internal;
using System.Collections;
using System.Windows.Forms;
using System.Diagnostics;

namespace GYH_ClassLib
{
    public static class logger
    {
        static FileStream fs;
        static logger()
        {
            string fileName = @ConfigurationManager.AppSettings["LogInfoLocation"] + "\\log.txt";

        }
        public static void log(string str)
        {
            string fileName = @ConfigurationManager.AppSettings["LogInfoLocation"] + "\\log.txt";
            fs = File.Open(fileName, FileMode.Append, FileAccess.Write);
            str = "[" + DateTime.Now.ToString() + "]" + str + "\r\n";
            fs.Write(System.Text.Encoding.Default.GetBytes(str), 0, str.Length);
            fs.Close();
        }
    }
    class FileOperate
    {

        private static void CopyFolder(string from, string to)
        {
            if (!Directory.Exists(to))
                Directory.CreateDirectory(to);

            // 子文件夹
            foreach (string sub in Directory.GetDirectories(from))
                CopyFolder(sub + "\\", to + Path.GetFileName(sub) + "\\");

            // 文件
            foreach (string file in Directory.GetFiles(from))
            {
                if (!File.Exists(to + Path.GetFileName(file)))
                {
                    File.Copy(file, to + Path.GetFileName(file), false);
                }
            }

            logger.log(string.Format("CopyFolder({0},{1})", from, to));
        }
    }
}
