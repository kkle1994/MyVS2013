﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using PYO_Simplified.Properties;
using System.Configuration;
using System.Configuration.Assemblies;
using System.Configuration.Internal;
using System.Collections;
using System.Windows.Forms;

namespace PYO_Simplified
{
    class FileCreate
    {
        
        public static DirectoryInfo ModelInfo = new DirectoryInfo(@Properties.Settings.Default.ModelFolder);
        public static void CopyModel(string company,string project)
        {
            try
            {
                string MF = ConfigurationManager.AppSettings["ModelFolder"];
                string CI = ConfigurationManager.AppSettings["CreateInto"];
                CopyFolder(@MF, @CI + "\\" + company + "\\" + project + "\\");
                CopyFolder(@CI + "\\" + company + "\\" + project + "\\Build\\v1.0.2015.xxxx\\", @Settings.Default.CreateInto + "\\" + company + "\\" + project + "\\Build\\v1.0." + DateTime.Today.Year.ToString() + "." + DateTime.Today.Month.ToString() + "." + DateTime.Today.Day.ToString() + "\\");
                DirectoryInfo di = new DirectoryInfo(@CI + "\\" + company + "\\" + project + "\\Build\\v1.0.2015.xxxx\\");
                di.Delete(true);
                FileInfo fi0 = new FileInfo(@CI + "\\" + company + "\\" + project + "\\Documents\\Company_Project_CheckList.doc");
                FileInfo fi1 = new FileInfo(@CI + "\\" + company + "\\" + project + "\\Documents\\Company_Project_Installation.doc");
                FileInfo fi2 = new FileInfo(@CI + "\\" + company + "\\" + project + "\\Documents\\Company_Project_Requirements.doc");
                FileInfo fi3 = new FileInfo(@CI + "\\" + company + "\\" + project + "\\Documents\\Company_Project_WorkEstimate.xls");
                fi0.MoveTo(@CI + "\\" + company + "\\" + project + "\\Documents\\" + company + "_" + project + "_CheckList.doc");
                fi1.MoveTo(@CI + "\\" + company + "\\" + project + "\\Documents\\" + company + "_" + project + "_Installation.doc");
                fi2.MoveTo(@CI + "\\" + company + "\\" + project + "\\Documents\\" + company + "_" + project + "_Requirements.doc");
                fi3.MoveTo(@CI + "\\" + company + "\\" + project + "\\Documents\\" + company + "_" + project + "_WorkEstimate.xls");
                MessageBox.Show("Successful Create");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public static void CopyModel(DirectoryInfo DI)
        {
            ModelInfo.MoveTo(DI.FullName);
        }

        private static void CopyFolder(string from, string to,bool b = false)
        {
            if (!Directory.Exists(to))
                Directory.CreateDirectory(to);

            // 子文件夹
            foreach (string sub in Directory.GetDirectories(from))
                CopyFolder(sub + "\\", to + Path.GetFileName(sub) + "\\");

            // 文件
            foreach (string file in Directory.GetFiles(from))
                File.Copy(file, to + Path.GetFileName(file), false);
        }
    }
}
