﻿namespace PYO_Simplified
{
    partial class Mainform
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_companyname = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_project = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lb_Version = new System.Windows.Forms.Label();
            this.lb_LastDate = new System.Windows.Forms.Label();
            this.lb_ProjectNumber = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cb_companyname
            // 
            this.cb_companyname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cb_companyname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cb_companyname.FormattingEnabled = true;
            this.cb_companyname.Location = new System.Drawing.Point(135, 30);
            this.cb_companyname.Name = "cb_companyname";
            this.cb_companyname.Size = new System.Drawing.Size(121, 21);
            this.cb_companyname.Sorted = true;
            this.cb_companyname.TabIndex = 0;
            this.cb_companyname.SelectedIndexChanged += new System.EventHandler(this.cb_companyname_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Company Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Project Name";
            // 
            // cb_project
            // 
            this.cb_project.FormattingEnabled = true;
            this.cb_project.Location = new System.Drawing.Point(135, 58);
            this.cb_project.Name = "cb_project";
            this.cb_project.Size = new System.Drawing.Size(121, 21);
            this.cb_project.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "label5";
            // 
            // lb_Version
            // 
            this.lb_Version.AutoSize = true;
            this.lb_Version.Location = new System.Drawing.Point(132, 109);
            this.lb_Version.Name = "lb_Version";
            this.lb_Version.Size = new System.Drawing.Size(42, 13);
            this.lb_Version.TabIndex = 7;
            this.lb_Version.Text = "Version";
            // 
            // lb_LastDate
            // 
            this.lb_LastDate.AutoSize = true;
            this.lb_LastDate.Location = new System.Drawing.Point(132, 137);
            this.lb_LastDate.Name = "lb_LastDate";
            this.lb_LastDate.Size = new System.Drawing.Size(49, 13);
            this.lb_LastDate.TabIndex = 8;
            this.lb_LastDate.Text = "2000.0.0";
            // 
            // lb_ProjectNumber
            // 
            this.lb_ProjectNumber.AutoSize = true;
            this.lb_ProjectNumber.Location = new System.Drawing.Point(132, 165);
            this.lb_ProjectNumber.Name = "lb_ProjectNumber";
            this.lb_ProjectNumber.Size = new System.Drawing.Size(77, 13);
            this.lb_ProjectNumber.TabIndex = 9;
            this.lb_ProjectNumber.Text = "ProjectNumber";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(181, 248);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "Confirm";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Mainform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 335);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lb_ProjectNumber);
            this.Controls.Add(this.lb_LastDate);
            this.Controls.Add(this.lb_Version);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cb_project);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cb_companyname);
            this.Name = "Mainform";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cb_companyname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_project;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lb_Version;
        private System.Windows.Forms.Label lb_LastDate;
        private System.Windows.Forms.Label lb_ProjectNumber;
        private System.Windows.Forms.Button button1;
    }
}

