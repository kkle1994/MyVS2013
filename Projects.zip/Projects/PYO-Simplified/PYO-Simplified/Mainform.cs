﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PYO_Simplified
{
    public partial class Mainform : Form
    {
        public int CompanyID;
        public DBOperate dbo = new DBOperate();
        public DataSet ds_Company;
        public DataSet ds_Project;
        public Mainform()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ds_Company = dbo.getDataSet("Select * from company", "tb_company");
            if(ds_Company == new DataSet())
            {
                MessageBox.Show("Failed to connect database");
            }
            DataTable tb = ds_Company.Tables["tb_company"];
            
                DataColumn dc = tb.Columns["name"];
                foreach(DataRow dr in tb.Rows)
                {
                    cb_companyname.Items.Add(dr[dc]);
                }
            
        }

        private void cb_companyname_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_project.Text = "";
            cb_project.Items.Clear();
            //获取公司ID
            ds_Company = dbo.getDataSet("Select * from company", "tb_company");
            DataTable tb = ds_Company.Tables["tb_company"];
            DataColumn dc = tb.Columns["companyid"];
            foreach(DataRow dr in tb.Rows)
            {
                if(dr.ItemArray[1].ToString() == cb_companyname.Text)
                    CompanyID = (int)dr.ItemArray[0];
            }
            //获取公司项目            
            ds_Company = dbo.getDataSet("select name from project where companyid = '" + CompanyID + "'","tb_projectname");
            DataTable tb_projectname = ds_Company.Tables["tb_projectname"];
            foreach (DataRow dr_projectname in tb_projectname.Rows)
            {
                cb_project.Items.Add(dr_projectname.ItemArray[0]);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FileCreate.CopyModel(cb_companyname.Text, cb_project.Text);
        }
    }
}
