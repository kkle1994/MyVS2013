﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Data.SqlClient;
using System.Data;

namespace IMServer
{
    public enum PrivateServerStatusLevel { Off, WaitingConnection, ConnectionEstablished };
    public delegate void PrivateNewConnectionEventHandler(string loginName, EventArgs e);
    public delegate void PrivateDataReceivedEventHandler(Object sender, string message, EventArgs e);
    public delegate void PrivateDisconnectedEventHandler(Object sender, EventArgs e);
    public delegate void PrivateBroadcastEventHandler(string message, EventArgs e);


    class BackMessage
    {
        private bool AlreadyDisposed;
        private Socket Listener;
        private int ConnectionsQueueLength;
        private int MaxBufferSize;
        private string Handshake;
        private StreamReader ConnectionReader;
        private StreamWriter ConnectionWriter;
        private Logger logger;
        private byte[] FirstByte;
        private byte[] LastByte;

        List<PrivateServerConnection> connectionSocketList = new List<PrivateServerConnection>();

        public PrivateServerStatusLevel Status { get; private set; }
        public int ServerPort { get; set; }
        public string ServerLocation { get; set; }
        public string ConnectionOrigin { get; set; }
        public bool LogEvents
        {
            get { return logger.LogEvents; }
            set { logger.LogEvents = value; }
        }

        public event PrivateNewConnectionEventHandler NewConnection;
        public event PrivateDataReceivedEventHandler DataReceived;
        public event PrivateDisconnectedEventHandler Disconnected;

        private void Initialize()//初始化
        {
            AlreadyDisposed = false;
            logger = new Logger();
            Status = PrivateServerStatusLevel.Off;
            ConnectionsQueueLength = 500;
            MaxBufferSize = 1024 * 100;
            FirstByte = new byte[MaxBufferSize];
            LastByte = new byte[MaxBufferSize];
            FirstByte[0] = 0x00;
            LastByte[0] = 0xFF;
            logger.LogEvents = true;
        }

        public BackMessage() //默认端口和服务器位置，开始初始化
        {
            ServerPort = 4140;
            ServerLocation = string.Format("ws://{0}:4140/chat", getLocalmachineIPAddress());
            Initialize();
        }
        DataSet User_Dataset = new DataSet();
        string User_string;
        public BackMessage(int serverPort, string serverLocation = "", string connectionOrigin = "")//自定义端口和服务器位置
        {
            serverLocation = string.Format("ws://{0}:" + ServerPort + "/chat", getLocalmachineIPAddress());
            ServerPort = serverPort;
            ConnectionOrigin = connectionOrigin;
            ServerLocation = serverLocation;
            Initialize();
        }
        ~BackMessage()//析构函数
        {
            Close();
        }
        public void Dispose()//释放
        {
            Close();
        }
        private void Close()//关闭每个连接
        {
            if (!AlreadyDisposed)
            {
                AlreadyDisposed = true;
                if (Listener != null) Listener.Close();
                foreach (PrivateServerConnection item in connectionSocketList)
                {
                    item.ConnectionSocket.Close();
                }
                connectionSocketList.Clear();
                GC.SuppressFinalize(this);
            }
        }

        public static IPAddress getLocalmachineIPAddress()//获取本机网络位置地址
        {
            string strHostName = Dns.GetHostName();
            IPHostEntry ipEntry = Dns.GetHostEntry(strHostName);

            foreach (IPAddress ip in ipEntry.AddressList)
            {
                //IPV4
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                    return ip;
            }

            return ipEntry.AddressList[0];
        }

        public void StartServer()//服务器开始
        {

            Char char1 = Convert.ToChar(65533);

            Listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
            Listener.Bind(new IPEndPoint(getLocalmachineIPAddress(), ServerPort));

            Listener.Listen(ConnectionsQueueLength);

            logger.Log(string.Format("登录服务器启动。监听地址：{0}, 端口：{1}", getLocalmachineIPAddress(), ServerPort));
            logger.Log(string.Format("登录服务器地址: ws://{0}:{1}/chat", getLocalmachineIPAddress(), ServerPort));

            while (true)
            {
                Socket sc = Listener.Accept();

                if (sc != null)
                {
                    System.Threading.Thread.Sleep(100);
                    PrivateServerConnection socketConn = new PrivateServerConnection();
                    socketConn.ConnectionSocket = sc;
                    socketConn.NewConnection += new PrivateNewConnectionEventHandler(socketConn_NewConnection);
                    socketConn.DataReceived += new PrivateDataReceivedEventHandler(socketConn_BroadcastMessage);
                    socketConn.Disconnected += new PrivateDisconnectedEventHandler(socketConn_Disconnected);
                    //开始接收
                    socketConn.ConnectionSocket.BeginReceive(socketConn.receivedDataBuffer,
                                                             0, socketConn.receivedDataBuffer.Length,
                                                             0, new AsyncCallback(socketConn.ManageHandshake),
                                                             socketConn.ConnectionSocket.Available);
                    connectionSocketList.Add(socketConn);//加入连接Listx
                }
            }
        }

        void socketConn_Disconnected(Object sender, EventArgs e)//离开时执行
        {
            PrivateServerConnection sConn = sender as PrivateServerConnection;
            if (sConn != null)
            {
                sConn.ConnectionSocket.Close();
                connectionSocketList.Remove(sConn);
            }
        }

        void socketConn_BroadcastMessage(Object sender, string message, EventArgs e)//登录时执行，获取客户列表
        {
            DBOperate dbo = new DBOperate();
            User_Dataset = dbo.getDataSet("Select user_uid,user_nickname,user_photo from tb_user", "tb_us");
            User_string = "";
            foreach (DataTable table in User_Dataset.Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    foreach (DataColumn column in table.Columns)
                    {
                        if (row[column].ToString() != "")
                        User_string += row[column].ToString()+ ";";
                        else
                            User_string += row[column].ToString() + " ;";
                    }
                }
            }

            PrivateServerConnection sConn = sender as PrivateServerConnection;
            ClientUser CU = new ClientUser(message);
            if (CU.legal())//分割数据包到一个客户实例
            {
                CU.getNickName();
                CU.getUID();
                CU.getPhoto();
                Console.WriteLine(CU.UserName + "   " + CU.UserPassword + "  IP:" + CU.IPAddress);
            }
            else
                Console.WriteLine("未找到该用户。");
            if(message.Length <= 52)//是否为标准登录包
            {
            PrivateServerConnection p = connectionSocketList.Find(x => x.clientuser.UID == CU.UID);
            Send(CU.UID.ToString()+";"+CU.NickName+";"+CU.PhotoURL,p);
            }
            else if(message.Length >= 53)//是否为私聊包
            {
                PrivateServerConnection p = connectionSocketList.Find(x => x.clientuser.UID.ToString() == message.Substring(48,5).Trim());
                if (p != null)
                {
                    Send(CU.UID.ToString(), p);
                    try
                    {
                        if (sConn.thread_SL.ThreadState == ThreadState.Running)
                            sConn.thread_SL.Abort();
                        else if (sConn.thread_SL == null)
                        {
                            WebSocketServer PC1 = new WebSocketServer(CU.UID);
                            ThreadStart pcts = new ThreadStart(PC1.StartServer);
                            sConn.thread_SL = new Thread(pcts);
                            sConn.thread_SL.Start();
                        }
                        else
                        {
                            WebSocketServer PC1 = new WebSocketServer(CU.UID);
                            ThreadStart pcts = new ThreadStart(PC1.StartServer);
                            sConn.thread_SL = new Thread(pcts);
                            sConn.thread_SL.Start();
                        }
                    }
                    catch(Exception exx)
                    {
                        logger.Log(exx.ToString());
                    }
                }
                else
                    Console.WriteLine("该用户未登录");
            }
        }
        
        void socketConn_NewConnection(string name, EventArgs e)//新连接建立时
        {
            if (NewConnection != null)
                NewConnection(name, EventArgs.Empty);
        }

        public void Send(string message,PrivateServerConnection PSC)//数据发送
        {
            message += ";;" + User_string;
            DataFrame dr = new DataFrame(message);//信息格式转换
            PSC.ConnectionSocket.Send(dr.GetBytes());//发送信息
        }

    }
}
