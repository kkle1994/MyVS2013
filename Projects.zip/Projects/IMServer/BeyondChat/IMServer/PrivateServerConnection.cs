﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Data.SqlClient;
using System.Net;
using System.Threading;

namespace IMServer
{
    public class ClientUser//用户类
    {
        public int UID;
        public string UserName;
        public string UserPassword;
        public string IPAddress;
        public string NickName;
        public string PhotoURL;

        public ClientUser(string UserMessage)
        {
            UserName = UserMessage.Substring(0, 20);
            UserPassword = UserMessage.Substring(20, 10);
            IPAddress = UserMessage.Substring(30, 15);
        }

        public ClientUser()
        { }
        public void getPhoto()
        {
            if(legal())
            {
                DBOperate dbo = new DBOperate();
                string str = dbo.Scalar("select user_photo from tb_user where user_username = '" + UserName + "'").ToString().Trim();
                PhotoURL = str;
            }
        }

        public  void getNickName()
        {
                        if (legal())
                        {
                            DBOperate dbo = new DBOperate();
                            string str = dbo.Scalar("select user_nickname from tb_user where user_username = '" + UserName + "'").ToString().Trim();
                            NickName = str;
                        }
        }
        public void getUID()
        {
            if (legal())
            {
                DBOperate dbo = new DBOperate();
                string str = dbo.Scalar("select user_UID from tb_user where user_username = '" + UserName + "'").ToString().Trim();
                UID = int.Parse(str);
            }
            
        }


        private bool legal(string userName, string userPassword)//用户名密码检查
        {
            if (DBOperate.CompSql(userName, "tb_User", "user_username"))
            {
                DBOperate dbo = new DBOperate();
                string str = "select * from tb_user where user_username =" + userName + "and user_password =" + userPassword;
                SqlDataReader reader = dbo.DBOperate_getReader(str);
                if (reader.Read())
                    return true;
                else
                    return false;
            }
            else return false;
        }

        public bool legal()//用户名密码检查
        {
            if (DBOperate.CompSql(UserName, "tb_User", "user_username"))
            {
                DBOperate dbo = new DBOperate();
                if (dbo.Scalar("select * from tb_user where user_username = '" + UserName  + "' and user_password = '" + UserPassword +"'") != null)
                    return true;
                else return false;
            }
            else return false;
        }

        public static void CreateUser(string username, string password)//创建新用户
        {
            if (!DBOperate.CompSql(username, "tb_User", "user_username"))
            {
                DBOperate dbo = new DBOperate();
                string[,] userstr = new string[2, 2] { { "user_username", "user_password" }, { username, password } };

                dbo.Insert(userstr, "tb_user");
            }
        }
    }//用户类


    public class PrivateServerConnection
    {
        private Logger logger;

        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private Boolean isDataMasked;
        public Boolean IsDataMasked
        {
            get { return isDataMasked; }
            set { isDataMasked = value; }
        }

        public Socket ConnectionSocket;
        public ClientUser clientuser;
        private int MaxBufferSize;
        private string Handshake;
        private string New_Handshake;
        private int ClientUID;

        public byte[] receivedDataBuffer;
        private byte[] FirstByte;
        private byte[] LastByte;
        private byte[] ServerKey1;
        private byte[] ServerKey2;

        public Thread thread_SL;

        public event PrivateNewConnectionEventHandler NewConnection;
        public event PrivateDataReceivedEventHandler DataReceived;
        public event PrivateDisconnectedEventHandler Disconnected;

        public PrivateServerConnection()//初始化，显示服务器环境
        {
            logger = new Logger();
            MaxBufferSize = 1024*100;
            receivedDataBuffer = new byte[MaxBufferSize];
            FirstByte = new byte[MaxBufferSize];
            LastByte = new byte[MaxBufferSize];
            FirstByte[0] = 0x00;
            LastByte[0] = 0xFF;

            Handshake = "HTTP/1.1 101 Web Socket Protocol Handshake" + Environment.NewLine;
            Handshake += "Upgrade: WebSocket" + Environment.NewLine;
            Handshake += "Connection: Upgrade" + Environment.NewLine;
            Handshake += "Sec-WebSocket-Origin: " + "{0}" + Environment.NewLine;
            Handshake += string.Format("Sec-WebSocket-Location: " + "ws://{0}:4141/chat" + Environment.NewLine, WebSocketServer.getLocalmachineIPAddress());
            Handshake += Environment.NewLine;

            New_Handshake = "HTTP/1.1 101 Switching Protocols" + Environment.NewLine;
            New_Handshake += "Upgrade: WebSocket" + Environment.NewLine;
            New_Handshake += "Connection: Upgrade" + Environment.NewLine;
            New_Handshake += "Sec-WebSocket-Accept: {0}" + Environment.NewLine;
            New_Handshake += Environment.NewLine;
        }

        private void Read(IAsyncResult status)//读取消息
        {
            try
            {
                ClientUser CU = new ClientUser();

                if (!ConnectionSocket.Connected) return;
                string messageReceived = string.Empty;
                string str = Encoding.UTF8.GetString(receivedDataBuffer);
                DataFrame dr = new DataFrame(receivedDataBuffer);//解析收到的包
                if (dr.Text.Length >= 45)//登录包内容切割
                {
                    CU.UserName = dr.Text.Substring(0, 20).Trim();
                    CU.UserPassword = dr.Text.Substring(20, 10).Trim();
                    CU.IPAddress = dr.Text.Substring(30, 15).Trim();
                    
                }
                if (CU.legal() && ConnectionSocket.Connected)
                {
                    CU.getUID();
                    clientuser = CU;
                    Console.WriteLine(CU.UserName + "   " + CU.UserPassword + "  UID:" + CU.UID);
                    DataReceived(this, dr.Text, EventArgs.Empty);
                    Console.WriteLine("登录信息已验证");
                    CU.IPAddress = ((IPEndPoint)(ConnectionSocket.RemoteEndPoint)).Address.ToString();
                }
                else
                {
                    throw new Exception("用户登录失败。");
                }
                if (!ConnectionSocket.Connected) return;
                Array.Clear(receivedDataBuffer, 0, receivedDataBuffer.Length);
                ConnectionSocket.BeginReceive(receivedDataBuffer, 0, receivedDataBuffer.Length, 0, new AsyncCallback(Read), null);
            }
            catch (Exception ex)
            {
                logger.Log("连接异常:" + ex.ToString());
                if (Disconnected != null)
                    Disconnected(this, EventArgs.Empty);
            }
        }

        private void BuildServerPartialKey(int keyNum, string clientKey)
        {
            string partialServerKey = "";
            byte[] currentKey;
            int spacesNum = 0;
            char[] keyChars = clientKey.ToCharArray(); 
            foreach (char currentChar in keyChars)
            {
                if (char.IsDigit(currentChar)) partialServerKey += currentChar;
                if (char.IsWhiteSpace(currentChar)) spacesNum++;
            }
            try
            {
                currentKey = BitConverter.GetBytes((int)(Int64.Parse(partialServerKey) / spacesNum));
                if (BitConverter.IsLittleEndian) Array.Reverse(currentKey);

                if (keyNum == 1) ServerKey1 = currentKey;
                else ServerKey2 = currentKey;
            }
            catch
            {
                if (ServerKey1 != null) Array.Clear(ServerKey1, 0, ServerKey1.Length);
                if (ServerKey2 != null) Array.Clear(ServerKey2, 0, ServerKey2.Length);
            }
        }
        public void ManageHandshake(IAsyncResult status)//解析包
        {

            string header = "Sec-WebSocket-Version:";
            int HandshakeLength = (int)status.AsyncState;
            byte[] last8Bytes = new byte[8];

            System.Text.UTF8Encoding decoder = new System.Text.UTF8Encoding();
            String rawClientHandshake = decoder.GetString(receivedDataBuffer, 0, HandshakeLength);
            if (HandshakeLength < 8)
            {

                if (Disconnected != null)
                    this.Disconnected(this, EventArgs.Empty);
            }
            else
            {
                Array.Copy(receivedDataBuffer, HandshakeLength - 8, last8Bytes, 0, 8);
                //现在使用的是比较新的Websocket协议
                if (rawClientHandshake.IndexOf(header) != -1)
                {
                    this.isDataMasked = true;
                    string[] rawClientHandshakeLines = rawClientHandshake.Split(new string[] { Environment.NewLine }, System.StringSplitOptions.RemoveEmptyEntries);
                    string acceptKey = "";
                    foreach (string Line in rawClientHandshakeLines)
                    {
                        Console.WriteLine(Line);
                        if (Line.Contains("Sec-WebSocket-Key:"))
                        {
                            acceptKey = ComputeWebSocketHandshakeSecurityHash09(Line.Substring(Line.IndexOf(":") + 2));
                        }
                    }

                    New_Handshake = string.Format(New_Handshake, acceptKey);
                    byte[] newHandshakeText = Encoding.UTF8.GetBytes(New_Handshake);
                    if (ConnectionSocket.Connected)
                        ConnectionSocket.BeginSend(newHandshakeText, 0, newHandshakeText.Length, 0, HandshakeFinished, null);
                    return;
                }

                string ClientHandshake = decoder.GetString(receivedDataBuffer, 0, HandshakeLength - 8);

                string[] ClientHandshakeLines = ClientHandshake.Split(new string[] { Environment.NewLine }, System.StringSplitOptions.RemoveEmptyEntries);

                logger.Log("新的连接请求来自" + ConnectionSocket.LocalEndPoint + "。正在准备连接 ...");

                // Welcome the new client
                foreach (string Line in ClientHandshakeLines)
                {
                    logger.Log(Line);
                    if (Line.Contains("Sec-WebSocket-Key1:"))
                        BuildServerPartialKey(1, Line.Substring(Line.IndexOf(":") + 2));
                    if (Line.Contains("Sec-WebSocket-Key2:"))
                        BuildServerPartialKey(2, Line.Substring(Line.IndexOf(":") + 2));
                    if (Line.Contains("Origin:"))
                        try
                        {
                            Handshake = string.Format(Handshake, Line.Substring(Line.IndexOf(":") + 2));
                        }
                        catch
                        {
                            Handshake = string.Format(Handshake, "null");
                        }
                }
                // Build the response for the client
                byte[] HandshakeText = Encoding.UTF8.GetBytes(Handshake);
                byte[] serverHandshakeResponse = new byte[HandshakeText.Length + 16];
                //byte[] serverKey = BuildServerFullKey(last8Bytes);
                Array.Copy(HandshakeText, serverHandshakeResponse, HandshakeText.Length);
                //Array.Copy(serverKey, 0, serverHandshakeResponse, HandshakeText.Length, 16);

                logger.Log("发送握手信息 ...");
                ConnectionSocket.BeginSend(serverHandshakeResponse, 0, HandshakeText.Length + 16, 0, HandshakeFinished, null);
                logger.Log(Handshake);
            }
        }

        public static String ComputeWebSocketHandshakeSecurityHash09(String secWebSocketKey)//SH1加密
        {
            const String MagicKEY = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
            String secWebSocketAccept = String.Empty;
            // 1. Combine the request Sec-WebSocket-Key with magic key.
            String ret = secWebSocketKey + MagicKEY;
            // 2. Compute the SHA1 hash
            SHA1 sha = new SHA1CryptoServiceProvider();
            byte[] sha1Hash = sha.ComputeHash(Encoding.UTF8.GetBytes(ret));
            // 3. Base64 encode the hash
            secWebSocketAccept = Convert.ToBase64String(sha1Hash);
            return secWebSocketAccept;
        }

        private void HandshakeFinished(IAsyncResult status)//停止握手发送，开始准备接收消息
        {
            try
            {
                ConnectionSocket.EndSend(status);
                ConnectionSocket.BeginReceive(receivedDataBuffer, 0, receivedDataBuffer.Length, 0, new AsyncCallback(Read), null);
                if (NewConnection != null)
                    NewConnection("", EventArgs.Empty);
            }
            catch(Exception ex)
            {
                if (Disconnected != null)
                    Disconnected(this, EventArgs.Empty);
                logger.Log(ex.ToString());
            }
        }
    
    }
}
