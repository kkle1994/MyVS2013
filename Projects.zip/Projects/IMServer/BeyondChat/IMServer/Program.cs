﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace IMServer
{
    class Program
    {
        static void Main(string[] args)
        {
            int port = 4141;
            WebSocketServer t0 = new WebSocketServer(port++);
            ThreadStart ts0 = new ThreadStart(t0.StartServer);
            Thread th0 = new Thread(ts0);
            th0.Start();
            WebSocketServer t1 = new WebSocketServer(port++);
            ThreadStart ts1 = new ThreadStart(t1.StartServer);
            Thread th1 = new Thread(ts1);
            th1.Start();
            WebSocketServer t2 = new WebSocketServer(port++);
            ThreadStart ts2 = new ThreadStart(t2.StartServer);
            Thread th2 = new Thread(ts2);
            th2.Start();
            WebSocketServer t3 = new WebSocketServer(port++);
            ThreadStart ts3 = new ThreadStart(t3.StartServer);
            Thread th3 = new Thread(ts3);
            th3.Start();
            WebSocketServer t4 = new WebSocketServer(port++);
            ThreadStart ts4 = new ThreadStart(t4.StartServer);
            Thread th4 = new Thread(ts4);
            th4.Start();
            WebSocketServer t5 = new WebSocketServer(port++);
            ThreadStart ts5 = new ThreadStart(t5.StartServer);
            Thread th5 = new Thread(ts5);
            th5.Start();
            BackMessage b1 = new BackMessage();
            b1.StartServer();
            
        }
    }
}
