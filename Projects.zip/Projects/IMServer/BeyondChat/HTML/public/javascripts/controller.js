angular.module('ngApp', []).controller('appController', function ($scope, $http) {
            var i, index=0;
            var webSocket = [];
            var userServer = "4140", serverSocket;
//            $scope.loginUserName = "Gavin"; $scope.loginPassword = "159753"; $scope.loginIP = "10.10.73.17";
            $scope.loginUserName = "Roger"; $scope.loginPassword = "123456"; $scope.loginIP = "10.10.73.17";
            $scope.mine = {
                'uid':'','name':'','photo':''
            };
            $scope.users = [
                {'name':'公共聊天室一','uid':'4141','photo':'https://raw.githubusercontent.com/Rabbit0306/123/master/img/chating2.png','messageCount':0,'message':[]},
                {'name':'公共聊天室二','uid':'4142','photo':'https://raw.githubusercontent.com/Rabbit0306/123/master/img/chating2.png','messageCount':0,'message':[]},
                {'name':'公共聊天室三','uid':'4143','photo':'https://raw.githubusercontent.com/Rabbit0306/123/master/img/chating.png','messageCount':0,'message':[]},
                {'name':'公共聊天室四','uid':'4144','photo':'https://raw.githubusercontent.com/Rabbit0306/123/master/img/chating.png','messageCount':0,'message':[]},
                {'name':'公共聊天室五','uid':'4145','photo':'https://raw.githubusercontent.com/Rabbit0306/123/master/img/chating3.png','messageCount':0,'message':[]},
                {'name':'公共聊天室六','uid':'4146','photo':'https://raw.githubusercontent.com/Rabbit0306/123/master/img/chating3.png','messageCount':0,'message':[]}
            ];

            var webSocketLogin = function(webSocket,username, password, remoteIP){
                if(username.length < 20 && password.length <10 && remoteIP.length<15){
                    for(i = username.length; i<20; i++){
                        username += " ";
                    }
                    for(i = password.length; i<10; i++){
                        password += " ";
                    }
                    for(i = remoteIP.length; i<15; i++){
                        remoteIP += " ";
                    }
                    webSocket.send(username + password + remoteIP);
                }
            };
            var slWebSocketLogin = function(webSocket,username, password, remoteIP, content){
                if(username.length < 20 && password.length <10 && remoteIP.length<15){
                    for(i = username.length; i<20; i++){
                        username += " ";
                    }
                    for(i = password.length; i<10; i++){
                        password += " ";
                    }
                    for(i = remoteIP.length; i<15; i++){
                        remoteIP += " ";
                    }
                    console.log(username + password + remoteIP + "sl:" + content);
                    webSocket.send(username + password + remoteIP + "sl:" + content);
                }
            };

            var webSocketInit = function () {
                if(window.WebSocket){
                    serverSocket = new WebSocket("ws://10.10.71.254:" + userServer + "/chat");
                    serverSocket.onopen = function () {
                        webSocketLogin(this,$scope.loginUserName,$scope.loginPassword,$scope.loginIP);
                    };
                    serverSocket.onmessage = function(event) {
                        console.log(event.data);
                        var i; var userData = {'name':'','uid':'','photo':'','messageCount':0,'message':[]};
                        var u_index = 6;
                        var data = event.data.split(';');
                        $scope.mine.uid = data[0];
                        $scope.mine.name = data[1];
                        $scope.mine.photo = data[2];
                        data = event.data.replace(/\;$/,'').split(';;');
                        data = data[1].split(';');
                        for (i = 0; i < data.length; i++) {
                            data[i] = data[i].replace(/\s*$/, '');
                            if( i%3 == 0 ){
                                userData.uid = data[i];
                            } else if( i%3 == 1 ){
                                userData.name = data[i];
                            } else if( i%3 == 2 ){
                                userData.photo = data[i];
                                $scope.users[u_index] = {'name':userData.name,'uid':userData.uid,'photo':userData.photo,'messageCount':0,'message':[]};
                                u_index++;
                            }
                        }
                        if (event.data != null) {
                            for (i = 0; i < $scope.users.length; i++) {
                                if($scope.users[i].name.match(/公共聊天室/) != null){
                                    webSocket[i] = new WebSocket("ws://10.10.71.254:" + $scope.users[i].uid + "/chat");
                                    webSocket[i].socketOwner = $scope.users[i].uid;
                                    webSocket[i].onopen = function () {
                                        var user = $('#' + this.socketOwner);
                                        user.removeClass('disable');
                                        if (this.socketOwner == "4141") {
                                            user.click();
                                        }
                                    };
                                    webSocket[i].onmessage = function (event) {
//                                        console.log("It is the " + this.socketOwner + "get message.");
                                        var data = event.data.split(/\[uid\]|\[photo\]| say:/);
                                        console.log(data);
                                        var uid = data[0];
                                        var photo = data[1];
                                        var name = data[2];
                                        var content = data[3];
                                        if(content != null) {
                                            for (var i = $scope.users.length - 1; i >= 0; i--) {
                                                if ($scope.users[i].uid == this.socketOwner) {
                                                    $scope.users[i].message[$scope.users[i].messageCount] = {
                                                        'time': Date.now(),
                                                        'uid': uid,
                                                        'photo': photo,
                                                        'name': name,
                                                        'content': content
                                                    };
                                                    $scope.currentMessage = $scope.users[i].message;
                                                    if($scope.currentMessage.length != 0) {
                                                        if ($scope.currentMessage[$scope.currentMessage.length - 1].name == $scope.mine.name) {
                                                            $scope.currentMessage[$scope.currentMessage.length - 1].IsMine = true;
                                                        }
                                                    }
                                                    $scope.$digest();
                                                    $('li.active')[0].click();
                                                    $scope.users[i].messageCount++;
                                                }
                                            }
                                        }
                                    }
                                } else {
//                                    slWebSocketLogin(this,$scope.loginUserName,$scope.loginPassword,$scope.loginIP,$scope.users[i].uid);
//                                    webSocket[i] = new WebSocket("ws://10.10.71.254:" + $scope.users[i].uid + "/chat");
//                                    webSocket[i].socketOwner = $scope.users[i].uid;
//                                    webSocket[i].onopen = function () {
//                                        var user = $('#' + this.socketOwner);
//                                        user.removeClass('disable');
//                                    };
                                }
                            }
                        }
                    }
                } else if(window.MozWebSocket){
                    serverSocket = new WebSocket("ws://10.10.71.254:" + userServer + "/chat");
                    serverSocket.onopen = function () {
                        webSocketLogin(this,$scope.loginUserName,$scope.loginPassword,$scope.loginIP);
                    };
                    serverSocket.onmessage = function(event) {
                        console.log(event.data);
                        var i; var userData = {'name':'','uid':'','photo':'','messageCount':0,'message':[]};
                        var u_index = 6;
                        var data = event.data.split(';');
                        $scope.mine.uid = data[0];
                        $scope.mine.name = data[1];
                        $scope.mine.photo = data[2];
                        data = event.data.replace(/\;$/,'').split(';;');
                        data = data[1].split(';');
                        for (i = 0; i < data.length; i++) {
                            data[i] = data[i].replace(/\s*$/, '');
                            if( i%3 == 0 ){
                                userData.uid = data[i];
                            } else if( i%3 == 1 ){
                                userData.name = data[i];
                            } else if( i%3 == 2 ){
                                userData.photo = data[i];
                                $scope.users[u_index] = {'name':userData.name,'uid':userData.uid,'photo':userData.photo,'messageCount':0,'message':[]};
                                u_index++;
                            }
                        }
                        if (event.data != null) {
                            for (i = 0; i < $scope.users.length; i++) {
                                if($scope.users[i].name.match(/公共聊天室/) != null){
                                    webSocket[i] = new WebSocket("ws://10.10.71.254:" + $scope.users[i].uid + "/chat");
                                    webSocket[i].socketOwner = $scope.users[i].uid;
                                    webSocket[i].onopen = function () {
                                        var user = $('#' + this.socketOwner);
                                        user.removeClass('disable');
                                        if (this.socketOwner == "4141") {
                                            user.click();
                                        }
                                    };
                                    webSocket[i].onmessage = function (event) {
//                                        console.log("It is the " + this.socketOwner + "get message.");
                                        var data = event.data.split(/\[uid\]|\[photo\]| say:/);
                                        console.log(data);
                                        var uid = data[0];
                                        var photo = data[1];
                                        var name = data[2];
                                        var content = data[3];
                                        if(content != null) {
                                            for (var i = $scope.users.length - 1; i >= 0; i--) {
                                                if ($scope.users[i].uid == this.socketOwner) {
                                                    $scope.users[i].message[$scope.users[i].messageCount] = {
                                                        'time': Date.now(),
                                                        'uid': uid,
                                                        'photo': photo,
                                                        'name': name,
                                                        'content': content
                                                    };
                                                    $scope.currentMessage = $scope.users[i].message;
                                                    if($scope.currentMessage.length != 0) {
                                                        if ($scope.currentMessage[$scope.currentMessage.length - 1].name == $scope.mine.name) {
                                                            $scope.currentMessage[$scope.currentMessage.length - 1].IsMine = true;
                                                        }
                                                    }
                                                    $scope.$digest();
                                                    $('li.active')[0].click();
                                                    $scope.users[i].messageCount++;
                                                }
                                            }
                                        }
                                    }
                                } else {
//                                    slWebSocketLogin(this,$scope.loginUserName,$scope.loginPassword,$scope.loginIP,$scope.users[i].uid);
//                                    webSocket[i] = new WebSocket("ws://10.10.71.254:" + $scope.users[i].uid + "/chat");
//                                    webSocket[i].socketOwner = $scope.users[i].uid;
//                                    webSocket[i].onopen = function () {
//                                        var user = $('#' + this.socketOwner);
//                                        user.removeClass('disable');
//                                    };
                                }
                            }
                        }
                    }
                } else {
                    $('#chatBox').addClass("disable");
                    $('#chatWindow').addClass("disable");
                    alert("Chat Box is error");
                }
            };
            webSocketInit();
            $scope.openDialog = function(index, event){
                var user = $('#'+$scope.users[index].uid);
                for(var i=$scope.users.length-1; i>=0; i--){
                    $('#'+$scope.users[i].uid).removeClass('active');
                }
                user.addClass('active');
                $('#dialTitle')[0].innerText = $scope.users[index].name + " 的对话";
                $scope.currentMessage = $scope.users[index].message;
                if($scope.currentMessage.length != 0) {
                    var container = $('#SendDataContainer');
                    container.scrollTop(container[0].scrollHeight);
                }
            };
            $scope.sendContent = function(event){
                var chatInput = $('#chatInput')[0];
                if(event.keyCode == 13){
                    for(var i = webSocket.length - 1; i>=0; i--){
                        if(webSocket[i].socketOwner == $('li.active')[0].id){
                            if(chatInput.value != ""){
                                webSocket[i].send($scope.mine.uid + "[uid]" + $scope.mine.photo + "[photo]" + $scope.mine.name + " say:" + chatInput.value);
                                chatInput.value = "";
                            }
                        }
                    }
                }
            };
        });