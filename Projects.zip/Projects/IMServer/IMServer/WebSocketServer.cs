﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace IMServer
{
    public class Logger
    {
        public bool LogEvents { get; set; }

        public Logger()
        {
            LogEvents = true;
        }

        public void Log(string Text)
        {
            if (LogEvents) Console.WriteLine(Text);
        }
    }

    public enum ServerStatusLevel { Off, WaitingConnection, ConnectionEstablished };
    public delegate void NewConnectionEventHandler(string loginName, EventArgs e);
    public delegate void DataReceivedEventHandler(Object sender, string message, EventArgs e);
    public delegate void DisconnectedEventHandler(Object sender, EventArgs e);
    public delegate void BroadcastEventHandler(string message, EventArgs e);

    public class WebSocketServer : IDisposable
    {
        private bool AlreadyDisposed;
        private Socket Listener;
        private int ConnectionsQueueLength;
        private int MaxBufferSize;
        private string Handshake;
        private StreamReader ConnectionReader;
        private StreamWriter ConnectionWriter;
        private Logger logger;
        private byte[] FirstByte;
        private byte[] LastByte;
        private byte[] ServerKey1;
        private byte[] ServerKey2;

        List<SocketConnection> connectionSocketList = new List<SocketConnection>();

        public ServerStatusLevel Status { get; private set; }
        public int ServerPort { get; set; }
        public string ServerLocation { get; set; }
        public string ConnectionOrigin { get; set; }
        public bool LogEvents
        {
            get { return logger.LogEvents; }
            set { logger.LogEvents = value; }
        }

        public event NewConnectionEventHandler NewConnection;
        public event DataReceivedEventHandler DataReceived;
        public event DisconnectedEventHandler Disconnected;

        private void Initialize()//初始化
        {
            AlreadyDisposed = false;
            logger = new Logger();

            Status = ServerStatusLevel.Off;
            ConnectionsQueueLength = 500;
            MaxBufferSize = 1024 * 100;
            FirstByte = new byte[MaxBufferSize];
            LastByte = new byte[MaxBufferSize];
            FirstByte[0] = 0x00;
            LastByte[0] = 0xFF;
            logger.LogEvents = true;
        }

        public WebSocketServer() //默认端口和服务器位置，开始初始化
        {
            ServerPort = 4141;
            ServerLocation = string.Format("ws://{0}:4141/chat", getLocalmachineIPAddress());
            Initialize();
        }

        public WebSocketServer(int serverPort,string serverLocation = "" , string connectionOrigin = "")//自定义端口和服务器位置
        {
            serverLocation = string.Format("ws://{0}:" + ServerPort + "/chat", getLocalmachineIPAddress());
            ServerPort = serverPort;
            ConnectionOrigin = connectionOrigin;
            ServerLocation = serverLocation;
            Initialize();
        }


        ~WebSocketServer()//析构函数
        {
            Close();
        }


        public void Dispose()//释放
        {
            Close();
        }

        private void Close()//关闭每个连接
        {
            if (!AlreadyDisposed)
            {
                AlreadyDisposed = true;
                if (Listener != null) Listener.Close();
                foreach (SocketConnection item in connectionSocketList)
                {
                    item.ConnectionSocket.Close();
                }
                connectionSocketList.Clear();
                GC.SuppressFinalize(this);
            }
        }

        public static IPAddress getLocalmachineIPAddress()//获取本机网络位置地址
        {
            string strHostName = Dns.GetHostName();
            IPHostEntry ipEntry = Dns.GetHostEntry(strHostName);

            foreach (IPAddress ip in ipEntry.AddressList)
            {
                //IPV4
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                    return ip;
            }

            return ipEntry.AddressList[0];
        }

        public void StartServer()//服务器开始
        {
            
            Char char1 = Convert.ToChar(65533);

            Listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
            Listener.Bind(new IPEndPoint(getLocalmachineIPAddress(), ServerPort));

            Listener.Listen(ConnectionsQueueLength);

            logger.Log(string.Format("聊天服务器启动。监听地址：{0}, 端口：{1}", getLocalmachineIPAddress(), ServerPort));
            logger.Log(string.Format("WebSocket服务器地址: ws://{0}:{1}/chat", getLocalmachineIPAddress(), ServerPort));

            while (true)
            {
                Socket sc = Listener.Accept();

                if (sc != null)
                {
                    System.Threading.Thread.Sleep(100);
                    SocketConnection socketConn = new SocketConnection();
                    socketConn.ConnectionSocket = sc;
                    socketConn.NewConnection += new NewConnectionEventHandler(socketConn_NewConnection);
                    socketConn.DataReceived += new DataReceivedEventHandler(socketConn_BroadcastMessage);
                    socketConn.Disconnected += new DisconnectedEventHandler(socketConn_Disconnected);
                    //开始接收
                    socketConn.ConnectionSocket.BeginReceive(socketConn.receivedDataBuffer,
                                                             0, socketConn.receivedDataBuffer.Length,
                                                             0, new AsyncCallback(socketConn.ManageHandshake),
                                                             socketConn.ConnectionSocket.Available);
                    connectionSocketList.Add(socketConn);//加入连接List
                }
            }
        }

        void socketConn_Disconnected(Object sender, EventArgs e)//离开时执行
        {
            SocketConnection sConn = sender as SocketConnection;
            if (sConn != null && ((IPEndPoint)sConn.ConnectionSocket.LocalEndPoint).Port >= 10000)
            {
                Send(string.Format("【{0}】离开了聊天室！", sConn.Name));
                sConn.ConnectionSocket.Close();
                connectionSocketList.Remove(sConn);
                if(connectionSocketList.Count == 0)
                {
                    this.Dispose();
                }
            }
            else
            {
                sConn.ConnectionSocket.Close();
                connectionSocketList.Remove(sConn);
            }
        }

        void socketConn_BroadcastMessage(Object sender, string message, EventArgs e)//登录时执行
        {
            SocketConnection sConn = sender as SocketConnection;
            if ((ServerPort >= 10000 && connectionSocketList.Count <= 2)||ServerPort <=5000)
            {
                if (message.IndexOf("login:") != -1)
                {

                    sConn.Name = message.Substring(message.IndexOf("login:") + "login:".Length);
                    message = string.Format("欢迎【{0}】来到聊天室！", message.Substring(message.IndexOf("login:") + "login:".Length));
                }
                Send(message);
            }
            else if(ServerPort >= 10000)
                Disconnected(sConn,EventArgs.Empty);
        }

        void socketConn_NewConnection(string name, EventArgs e)//无用函数
        {
            if (NewConnection != null)
                NewConnection(name, EventArgs.Empty);
        }

        public void Send(string message)//数据发送
        {
            if (!File.Exists("D:\\Test\\IMServerLog\\" + DateTime.Today.Year + DateTime.Today.Month + DateTime.Today.Day + ".txt"))
            {
                File.Create("D:\\Test\\IMServerLog\\" + DateTime.Today.Year + DateTime.Today.Month + DateTime.Today.Day + ".txt");
            }
            using (System.IO.StreamWriter file = new System.IO.StreamWriter("D:\\Test\\IMServerLog\\" + DateTime.Today.Year + DateTime.Today.Month + DateTime.Today.Day+".txt", true))
            {
                file.WriteLine(this.ServerPort +  " "+ DateTime.Now.ToShortTimeString() + message);// 直接追加文件末尾，换行   
            }
            foreach (SocketConnection item in connectionSocketList)//遍历所有连接
            {
                if (!item.ConnectionSocket.Connected) return;//是否已连接
                try
                {
                    if (item.IsDataMasked)
                    {
                        DataFrame dr = new DataFrame(message);//信息格式转换
                        item.ConnectionSocket.Send(dr.GetBytes());//发送信息
                        int i = 1;
                    }
                    else
                    {
                        item.ConnectionSocket.Send(FirstByte);
                        item.ConnectionSocket.Send(Encoding.UTF8.GetBytes(message));
                        item.ConnectionSocket.Send(LastByte);
                    }
                }
                catch (Exception ex)
                {
                    logger.Log(ex.Message);
                }
            }
        }
    }
}
