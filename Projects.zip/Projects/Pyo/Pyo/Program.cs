﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pyo.DAL;
using Pyo.Modules;
using Pyo.BusinessLogic;

namespace Pyo
{
    class Program
    {
        static void Main(string[] args)
        {
            
            DBOperate dbo = new DBOperate();
            dbo.DBOperate_getconnection();
            Console.WriteLine("数据库连接成功");
            Console.WriteLine();
            if (args.Length == 0)
            {
                while (true)
                {
                    string str = Console.ReadLine();
                    CommandReader CR = new CommandReader(str);
                    Args cmd = CR.args;
                    if (cmd.userName != "admin")
                    {
                        Console.WriteLine("用户名或密码不正确");
                        continue;
                    }
                    Company company = WebClient.GetCompany(cmd.companyName, cmd.projectName);
                    if (!company.IsCompanyExisted() || !company.IsProjectExisted())
                    {
                        Console.WriteLine("公司或项目不存在");
                        continue;
                    }
                    FileSystem.CreateProject(company, cmd);
                }
            }
            else
            {
                CommandReader crr = new CommandReader(args);
                Console.WriteLine("按任意键退出");
                Console.ReadKey();
            }
            /*
            Args cmd = new Args();
            ProgramLogic.ParseArgs(args, cmd);
            if (cmd.userName != "admin")
            {
                return;
            }
            Company company = WebClient.GetCompany(cmd.companyName, cmd.projectName);
            if (!company.IsCompanyExisted() || !company.IsProjectExisted())
            {
                return;
            }
            FileSystem.CreateProject(company, cmd);
            Console.ReadLine();
            */
        }
    }
}
