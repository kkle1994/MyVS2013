﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Pyo
{
    public class Args
    {
        public string companyName { get; set; }
        public string projectName { get; set; }
        public string buildName { get; set; }
        public string productName { get; set; }
        public string typeName { get; set; }
        public string versionName { get; set; }
        public string userName { get; set; }
        public string userPassword { get; set; }
    }
    class CommandReader
    {
        public Args args = new Args();

        public CommandReader(string str)
        {
            try
            {
                args = ReadCMD(str);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
        public CommandReader(string[] str)
        {
            try
            {
                ReadCMD(str);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public Args ReadCMD(string[] str)//解析已经切割的字符串数组
        {
            string[] cmdarray = ArgsSplit(str);
             if (cmdarray.Length <= 1&& cmdarray[0] != "-help")
                            throw new Exception("缺少参数");
            else
                for (int i = 0; i < cmdarray.Length; )
                {
                    switch (cmdarray[i])
                    {


                        case "-c":
                            if (cmdarray.Length <= i + 1)
                                throw new Exception("缺少参数");
                            else if ((string)cmdarray[i + 1].Substring(0, 1) == "-")
                                throw new Exception("缺少参数");
                            else
                                args.companyName = cmdarray[i + 1];
                            i++;
                            i++;
                            break;


                        case "-p":
                            if (cmdarray.Length <= i + 1)
                                throw new Exception("缺少参数");
                            else if ((string)cmdarray[i + 1].Substring(0, 1) == "-")
                                throw new Exception("缺少参数");
                            else
                                args.projectName = cmdarray[i + 1];
                            i++;
                            i++;
                            break;



                        case "-P":
                            if (cmdarray.Length <= i + 1)
                                throw new Exception("缺少参数");
                            else if ((string)cmdarray[i + 1].Substring(0, 1) == "-")
                                throw new Exception("缺少参数");
                            else
                            {
                                args.productName = cmdarray[i + 1].Trim().Split('/').ElementAtOrDefault(0);
                                args.typeName = cmdarray[i + 1].Trim().Split('/').ElementAtOrDefault(1);
                                args.versionName = cmdarray[i + 1].Trim().Split('/').ElementAtOrDefault(2);
                                //args.productName = cmdarray[i + 1];
                            }
                            i++;
                            i++;
                            break;



                        case "-t":
                            if (cmdarray.Length <= i + 1)
                                throw new Exception("缺少参数");
                            else if ((string)cmdarray[i + 1].Substring(0, 1) == "-")
                                throw new Exception("缺少参数");
                            else
                                args.typeName = cmdarray[i + 1];
                            i++;
                            i++;
                            break;




                        case "-a":
                            if (cmdarray.Length <= i + 1)
                                throw new Exception("缺少参数");
                            else if ((string)cmdarray[i + 1].Substring(0, 1) == "-")
                                throw new Exception("缺少参数");
                            else
                                args.userName = cmdarray[i + 1];
                            if (cmdarray.Length <= i + 2)
                                if ((string)cmdarray[i + 2].Substring(0, 1) == "-")
                                {
                                    args.userPassword = "";
                                    i++;
                                    i++;
                                }
                                else
                                {
                                    args.userPassword = cmdarray[i + 2];
                                    i++;
                                    i++;
                                    i++;
                                }
                            break;


                        case "-b":
                            if (cmdarray.Length <= i + 1)
                                throw new Exception("缺少参数");
                            else if ((string)cmdarray[i + 1].Substring(0, 1) == "-")
                                throw new Exception("缺少参数");
                            else
                                args.buildName = cmdarray[i + 1];
                            i++;
                            i++;
                            break;


                        case "-help":
                            Console.WriteLine(Properties.Resources.HelpText);
                            string s = Console.ReadLine();
                            ReadCMD(s);
                            args = new Args();
                            goto A;
                        default:
                            throw new Exception("命令不正确，请输入-help查看参数");
                    }
                }
            return args;
            A:
            return new Args();
        }


        public Args ReadCMD(string str)//解析命令行
        {
            if (str == "") return null;
            string[] cmdarray = str.Split();
            if (cmdarray.Length <= 1 && cmdarray[0] != "-help")
                throw new Exception("缺少参数");
            else
                return ReadCMD(cmdarray);
        }


        private string[] ArgsSplit(string[] str)
        {
            ArrayList a = new ArrayList();
            foreach(string s in str)//数组复制
            {
                a.Add(s);
            }


            for(int i = 0;i<a.Count;i++)
            {
                string s1 = (string)a[i];
                if(s1.Substring(0,1) == "\""&& s1.Substring(s1.Length-1) != "\"")
                {
                    s1 = s1.Substring(1);
                    int i2 = i;
                    i++;
                    for(;i<a.Count-1;)
                    {
                        string s2 = (string)a[i];
                        if (s2.Substring(s2.Length -1) != "\"")
                        {
                            
                            s1 = s1 + " " + s2;
                            a[i2] = s1;
                            a.RemoveAt(i);
                        }
                        else
                        {
                            s1 = s1 +" " + s2.Substring(0,s2.Length - 1);
                            a[i2] = s1;
                            a.RemoveAt(i);
                            i++;
                            break;
                        }
                    }
                }
            }
            a.CopyTo(str);
            return str;
        }

    }
}
