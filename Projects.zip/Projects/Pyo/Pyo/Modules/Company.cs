﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pyo.Modules
{
    public class Company
    {
        public class CProjectHref
        {
            public class ProjectInfo
            {
                [JsonProperty("_id")]
                public string ID { get; set; }
                [JsonProperty("projectId")]
                public int ProjectId { get; set; }
                [JsonProperty("name")]
                public string name { get; set; }
                [JsonProperty("status")]
                public int status { get; set; }
            }
            [JsonProperty("project")]
            public ProjectInfo projectInfo { get; set; }
            [JsonProperty("href")]
            public string Href { get; set; }
        }
        public class CProject
        {
            [JsonProperty("_id")]
            public string ID { get; set; }

            [JsonProperty("projectId")]
            public int ProjectId { get; set; }

            [JsonProperty("name")]
            public string Name { get; set; }

            [JsonProperty("companyId")]
            public string CompanyId { get; set; }

            [JsonProperty("assemblyName")]
            public string AssemblyName { get; set; }

            [JsonProperty("currentVersion")]
            public string CurrentVersion { get; set; }

            [JsonProperty("description")]
            public string Description { get; set; }

            [JsonProperty("isProduct")]
            public bool IsProduct { get; set; }

            [JsonProperty("isWebService")]
            public bool IsWebService { get; set; }

            [JsonProperty("isPAPI")]
            public bool IsPAPI { get; set; }

            [JsonProperty("isUtility")]
            public bool IsUtility { get; set; }

            [JsonProperty("isCodeBase")]
            public bool IsCodeBase { get; set; }

            [JsonProperty("isPlugin")]
            public bool IsPlugin { get; set; }
        }
        [JsonProperty("_id")]
        public string ID { get; set; }

        [JsonProperty("companyId")]
        public int CompanyId { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("clientId")]
        public string ClientId { get; set; }

        [JsonProperty("serverFolder")]
        public string ServerFolder { get; set; }

        [JsonProperty("perforceFolder")]
        public string PerforceFolder { get; set; }

        [JsonProperty("obsolete")]
        public bool Obsolete { get; set; }
        [JsonProperty("projects")]
        private string[] ProjectID { get; set; }

        public CProjectHref[] ProjectsHref { get; set; }

        public string ProjectHref { get; set; }

        public CProject Project { get; set; }
        public bool IsCompanyExisted()
        {
            if (this.Name != null)
            {
                return true;
            }
            return false;
        }
        public bool IsProjectExisted()
        {
            if (this.Project != null)
            {
                return true;
            }
            return false;
        }
    }
}
