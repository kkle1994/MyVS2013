﻿using Pyo.BusinessLogic;
using Pyo.Modules;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Pyo.DAL
{
    public class FileSystem
    {
        static string versionLast { get; set; }
        public static void CreateProject(Company company, Args args)
        {
            string FileCopyFrom = ConfigurationManager.AppSettings["FileCopyFrom"];
            string ProductsFrom = ConfigurationManager.AppSettings["ProductsFrom"];

            #region Modity Build Folder
            string rootFolder = string.Format("{0}\\{1}\\{2}", ConfigurationManager.AppSettings["FileCopyInto"], company.Name, company.Project.Name);
            FileSystem.CreateFolder(rootFolder, "Build");
            FileSystem.CreateFolder(rootFolder, "Build\\Release");
            FileSystem.CreateBuild(rootFolder, ProductsFrom, args, company);
            FileSystem.CreateTXT(rootFolder, "Build", "history.txt", string.Empty);
            #endregion

            #region Modity Documents Folder
            FileSystem.CreateFolder(rootFolder, "Documents");
            FileSystem.PasteDoucments(rootFolder, FileCopyFrom, args);
            #endregion

            #region Modity SourceCode Folder
            FileSystem.CreateFolder(rootFolder, "SourceCode");
            #endregion

            FileSystem.CreateTXT(rootFolder, string.Empty, "project.txt", string.Empty);

        }

        #region Method

        #region Method of Doucments
        public static void PasteDoucments(string rootFolder, string copyFrom, Args args)
        {
            string from = string.Format("{0}\\{1}", copyFrom, "Documents");
            string to = string.Format("{0}\\{1}", rootFolder, "Documents");
            FileInfo[] srcFiles = new DirectoryInfo(from).GetFiles();
            PasteDoucment(to, from, string.Format("{0}_{1}_CheckList.doc", args.companyName, args.projectName), args);
            PasteDoucment(to, from, string.Format("{0}_{1}_Requirements.doc", args.companyName, args.projectName), args);
            PasteDoucment(to, from, string.Format("{0}_{1}_Installation.doc", args.companyName, args.projectName), args);
            PasteDoucment(to, from, string.Format("{0}_{1}_WorkEstimate.xls", args.companyName, args.projectName), args);
        }

        public static void PasteDoucment(string copyTo, string copyFrom, string fileName, Args args)
        {
            try
            {
                string url = string.Format("{0}\\{1}", copyTo, fileName);
                string DoucmentType = fileName.Split('_').ElementAtOrDefault(2);
                FileInfo[] Doucments = new DirectoryInfo(copyFrom).GetFiles();
                foreach (FileInfo Doucment in Doucments)
                {
                    if (DoucmentType == Doucment.Name.Split('_').ElementAtOrDefault(2) && !File.Exists(url))
                    {
                        Doucment.CopyTo(url);
                        Console.WriteLine(string.Format("Info: Documents\\{0} is successful.", fileName));
                    }
                }
            }
            catch (Exception)
            {
                Console.WriteLine(string.Format("Error: Documents\\{0} is failed.", fileName));
            }
        }
        #endregion

        #region Method of Build

        public static void CreateBuild(string rootFolder, string copyFrom, Args args, Company company)
        {
            #region define the path
            string buildPath = string.Format("Build\\v{0}.{1}", "1.0", DateTime.Now.ToString("yyyy.MMdd"));
            string copyTo = string.Format("{0}\\{1}", rootFolder, buildPath);
            #endregion

            FileSystem.CreateFolder(rootFolder, string.Format("{0}\\{1}", buildPath, "installer"));

            #region Project IsPlugin
            if (company.Project.IsPlugin == true)
            {
                FileSystem.CreateFolder(rootFolder, string.Format("{0}\\{1}\\{2}", buildPath, "installer", "CustomData"));
                FileSystem.CreateFolder(rootFolder, string.Format("{0}\\{1}\\{2}", buildPath, "installer", "Plugins"));
                CreateBuildFiles(copyTo, copyFrom, args, company);
            }
            #endregion

            #region Project IsCodeBase
            if (company.Project.IsCodeBase == true)
            {
                FileSystem.CreateFolder(rootFolder, string.Format("{0}\\{1}\\{2}", buildPath, "installer", "CustomData"));
                FileSystem.CreateFolder(rootFolder, string.Format("{0}\\{1}\\{2}", buildPath, "installer", "InputForms"));
                FileSystem.CreateFolder(rootFolder, string.Format("{0}\\{1}\\{2}", buildPath, "installer", "Plugins"));
                CreateBuildFiles(copyTo, copyFrom, args, company);
            }
            #endregion

            #region Project IsUtility
            else if (company.Project.IsUtility == true)
            {
                if (args.productName != string.Empty)
                {
                    CreateBuildFiles(copyTo, copyFrom, args, company);
                }
            }
            #endregion

            FileSystem.CreateFolder(rootFolder, string.Format("{0}\\{1}", buildPath, "testcase"));
            FileSystem.CreateTXT(rootFolder, buildPath, args);
        }
        public static string GetLastBuild(string ProductPath, Company company, Args args)
        {
            string lastDate = string.Empty;
            string lastVersion = string.Empty;
            DirectoryInfo[] builds = new DirectoryInfo(ProductPath).GetDirectories();

            #region Search the last build
            foreach (DirectoryInfo build in builds)
            {
                if (!char.IsLetter(build.Name, 2))
                {
                    string[] buildname = build.Name.Replace("v", string.Empty).Split('.');
                    string version = string.Format("{0}.{1}", buildname.ElementAt(0), buildname.ElementAt(1));
                    string date = string.Format("{0}.{1}", buildname.ElementAt(2), buildname.ElementAt(3));
                    if (company.Project.AssemblyName == "WarehouseBatchExportPlugin")
                    {
                        if (args.versionName == version)
                        {
                            if (string.Compare(lastDate, date) == -1)
                            {
                                lastDate = date;
                                lastVersion = version;
                            }
                        }
                    }
                    else
                    {
                        if (string.Compare(lastVersion, version) != 1)
                        {
                            if (string.Compare(lastDate, date) == -1)
                            {
                                lastDate = date;
                                lastVersion = version;
                            }
                        }
                    }
                }
            }
            if (lastVersion == string.Empty)
            {
                Console.WriteLine("Error: Cannot find the build.");
                Environment.Exit(0);
            }
            #endregion

            return string.Format("v{0}.{1}", lastVersion, lastDate);
        }
        private static void CreateBuildFiles(string copyTo, string copyFrom, Args args, Company company)
        {
            if (args.productName != null)
            {
                if (args.typeName != null)
                {
                    #region Open the Mapping of CustomData file
                    XmlDocument ProductMapping = new XmlDocument();
                    ProductMapping.Load("Products.xml");
                    #endregion

                    #region Get the Product file from Mapping
                    XmlNodeList Products = ProductMapping.GetElementsByTagName("Product");
                    foreach (XmlNode Product in Products)
                    {
                        if (Product.Attributes["AssemblyName"].Value == company.Project.AssemblyName && Product.Attributes["version"].Value == args.versionName)
                        {
                            string ProductPath = string.Format("{0}\\{1}\\{2}", copyFrom, Product.Attributes["ProductFolder"].Value, "Build");
                            versionLast = FileSystem.GetLastBuild(ProductPath, company, args);
                            ProductPath = string.Format("{0}\\{1}", ProductPath, versionLast);

                            #region Foreach the CustomData Files
                            FileInfo[] CustomDataFiles = new DirectoryInfo(string.Format("{0}\\{1}", ProductPath, "installer\\CustomData")).GetFiles();
                            foreach (XmlNode ProductType in Product.ChildNodes)
                            {
                                if (ProductType.Name == args.typeName)
                                {
                                    foreach (XmlNode filename in ProductType.ChildNodes)
                                    {
                                        foreach (FileInfo CustomDataFile in CustomDataFiles)
                                        {
                                            if (filename.InnerText == CustomDataFile.Name)
                                            {
                                                #region Copy the files
                                                try
                                                {
                                                    CustomDataFile.CopyTo(string.Format("{0}\\{1}\\{2}", copyTo, "installer\\CustomData", CustomDataFile.Name), true).Attributes = FileAttributes.Normal;
                                                    Console.WriteLine(string.Format("Info: {0} is successful.", string.Format("{0}\\{1}\\{2}", copyTo, "installer\\CustomData", CustomDataFile.Name)));
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(string.Format("Error: {0} is failed.", string.Format("{0}\\{1}\\{2}", copyTo, "installer\\CustomData", CustomDataFile.Name)));
                                                }
                                                #endregion
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region Foreach the Plugins Files
                            FileInfo[] PluginsFiles = new DirectoryInfo(string.Format("{0}\\{1}", ProductPath, "installer\\Plugins")).GetFiles();
                            foreach (FileInfo PluginsFile in PluginsFiles)
                            {
                                try
                                {
                                    PluginsFile.CopyTo(string.Format("{0}\\{1}\\{2}", copyTo, "installer\\Plugins", PluginsFile.Name)).Attributes = FileAttributes.Normal;
                                    Console.WriteLine(string.Format("Info: {0} is successful.", string.Format("{0}\\{1}\\{2}", copyTo, "installer\\Plugins", PluginsFile.Name)));
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine(string.Format("Error: {0} is failed.", string.Format("{0}\\{1}\\{2}", copyTo, "installer\\Plugins", PluginsFile.Name)));
                                }
                            }
                            #endregion

                            #region Foreach the empkg Files
                            FileInfo[] empkgFiles = new DirectoryInfo(ProductPath).GetFiles();
                            foreach (FileInfo empkgFile in empkgFiles)
                            {
                                if (empkgFile.Extension == ".empkg")
                                {
                                    try
                                    {
                                        empkgFile.CopyTo(string.Format("{0}\\{1}", copyTo, empkgFile.Name)).Attributes = FileAttributes.Normal;
                                        Console.WriteLine(string.Format("Info: {0} is successful.", string.Format("{0}\\{1}", copyTo, empkgFile.Name)));
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine(string.Format("Error: {0} is failed.", string.Format("{0}\\{1}\\{2}", copyTo, "installer\\Plugins", empkgFile.Name)));
                                    }
                                }
                            }
                            #endregion

                        }
                    }
                    #endregion
                }
                else
                {
                    string ProductPath = string.Format("{0}\\{1}\\{2}", copyFrom, args.productName, "Build");
                    versionLast = FileSystem.GetLastBuild(ProductPath, company, args);
                    ProductPath = string.Format("{0}\\{1}", ProductPath, versionLast);
                    FileSystem.CopyAllFiles(copyTo, ProductPath, args, company);
                }
            }
        }
        public static void CreateAllDirectory(string dstFolderPath, string folderName)
        {
            DirectoryInfo[] Directorys = new DirectoryInfo(dstFolderPath).GetDirectories();
        }
        public static void CopyAllFiles(string copyTo, string copyFrom, Args args, Company company)
        {
            FileInfo[] Files = new DirectoryInfo(copyFrom).GetFiles();
            DirectoryInfo[] Directorys = new DirectoryInfo(copyFrom).GetDirectories();
            foreach (FileInfo File in Files)
            {
                if (File.Name != "update.txt")
                {
                    Directory.CreateDirectory(copyTo);
                    File.CopyTo(string.Format("{0}\\{1}", copyTo, File.Name), true).Attributes = FileAttributes.Normal;
                    Console.WriteLine(string.Format("Info: {0} is successful.", File.Name));
                }
            }
            foreach (DirectoryInfo Directory in Directorys)
            {
                CopyAllFiles(string.Format("{0}\\{1}", copyTo, Directory.Name), string.Format("{0}\\{1}", copyFrom, Directory.Name), args, company);
            }
        }
        #endregion
        public static void GetDLLversion()
        {

        }
        #region Method of TXT files
        public static void CreateTXT(string rootFolder, string buildPath, Args args)
        {
            StringBuilder txtContent = new StringBuilder();
            txtContent.AppendLine(string.Format("Last modified: 	    {0}", DateTime.Now.ToString("MM-dd-yyyy")));
            txtContent.AppendLine(string.Format("Modified by:	    {0}", string.Empty));
            txtContent.AppendLine(string.Format("Test By:            {0}", string.Empty));
            txtContent.AppendLine(string.Format("Description:        {0}", "New Project"));
            txtContent.AppendLine(string.Format("DLL Version:        {0}\r\n", string.Format("{0}             ", versionLast).Remove(14)));
            txtContent.AppendLine(string.Format("Files Changes:      {0}\r\n", "All files"));
            txtContent.AppendLine(string.Format("Configuration file: {0}\r\n", "All files"));
            txtContent.AppendLine("Source Code Control:");
            txtContent.AppendLine(string.Format("	Project build folder:  //Dev-PS/{0}/{1}/build/{2}", args.companyName, args.projectName, string.Format("v{0}.{1}", "1.0", DateTime.Now.ToString("yyyy.MMdd"))));
            txtContent.AppendLine(string.Format("	Product build folder:  //Dev-PS/Products/{0}/Build/{1}", args.productName, versionLast));
            txtContent.AppendLine(string.Format("Note:   packaged from product: //Dev-PS/Products/{0}/SourceCode", args.productName));
            FileSystem.CreateTXT(rootFolder, buildPath, "update.txt", txtContent.ToString());
        }
        public static void CreateTXT(string rootFolder, string buildPath, string txtName, string txtContent)
        {
            try
            {
                string url = string.Format("{0}\\{1}\\{2}", rootFolder, buildPath, txtName);
                if (!File.Exists(url))
                {
                    FileStream txtFile = new FileStream(url, FileMode.OpenOrCreate, FileAccess.Write);
                    StreamWriter txtWriter = new StreamWriter(txtFile);
                    txtWriter.Write(txtContent);
                    txtWriter.Close();
                    txtFile.Close();
                    if (buildPath == string.Empty)
                        Console.WriteLine(string.Format("Info: {0} is successful.", txtName));
                    else
                        Console.WriteLine(string.Format("Info: {0}\\{1} is successful.", buildPath, txtName));
                }
            }
            catch (Exception)
            {
                Console.WriteLine(string.Format("Error: {0} is failed.", txtName));
            }
        }
        #endregion

        #region Method of Folder
        public static void CreateFolder(string dstFolderPath, string folderName)
        {
            try
            {
                string url = string.Format("{0}\\{1}", dstFolderPath, folderName);
                if (new DirectoryInfo(url).Exists == false)
                {
                    DirectoryInfo a = Directory.CreateDirectory(url);
                    Console.WriteLine((string.Format("Info: {0} is successful.", folderName)));
                }
            }
            catch (Exception)
            {
                Console.WriteLine(string.Format("Error: {0} is failed.", folderName));
            }
        }
        #endregion

        #endregion
    }
}
