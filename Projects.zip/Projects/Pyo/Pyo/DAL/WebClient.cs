﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Pyo.Modules;

namespace Pyo
{
    public class WebClient
    {
        public static Company GetCompany(string companyName, string projectName)
        {
            try
            {
                // Create url from args
                string url = string.Format("{0}{1}{2}", ConfigurationManager.AppSettings["WebServerIP"], "/rest/company?conditions.name=", companyName);
                // Connected to remote server
                HttpWebRequest webRequest = WebRequest.Create(url) as HttpWebRequest;
                HttpWebResponse webResponse = webRequest.GetResponse() as HttpWebResponse;
                // Get Response from remote server
                using (StreamReader reader = new StreamReader(webResponse.GetResponseStream()))
                {
                    string readstring = reader.ReadToEnd();
                    // If the company is offline
                    if (readstring=="[]")
                    {
                        Console.WriteLine("Error: The Company is not exsited.");
                    }
                    // If the company is online
                    else
                    {
                        Company company = JsonConvert.DeserializeObject<Company[]>(readstring).ElementAtOrDefault<Company>(0);
                        company.ProjectHref = GetProjectHerf(company, projectName);
                        company.Project = GetProject(company.ProjectHref);
                        return company;
                    }
                }
            }
            // Connction error
            catch (Exception)
            {
                Console.WriteLine("Error: The connection is error.");
            }
            return new Company();
        }

        private static Company.CProject GetProject(string projectHref)
        {
            try
            {
                if (projectHref != null)
                {
                    // Create url from args
                    string url = string.Format("{0}{1}", ConfigurationManager.AppSettings["WebServerIP"], projectHref);
                    // Connected to remote server
                    HttpWebRequest webRequest = WebRequest.Create(url) as HttpWebRequest;
                    HttpWebResponse webResponse = webRequest.GetResponse() as HttpWebResponse;
                    // Get Response from remote server
                    using (StreamReader reader = new StreamReader(webResponse.GetResponseStream()))
                    {
                        Company.CProject project = JsonConvert.DeserializeObject<Company.CProject>(reader.ReadToEnd());
                        return project;
                    }
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Error: The connection is error.");
            }
            return new Company.CProject();
        }

        private static string GetProjectHerf(Company company, string projectName)
        {
            try
            {
                // Create url from args
                string url = string.Format("{0}{1}{2}{3}", ConfigurationManager.AppSettings["WebServerIP"], "/rest/company/", company.CompanyId, "/projects");

                // Connected to remote server
                HttpWebRequest webRequest = WebRequest.Create(url) as HttpWebRequest;
                HttpWebResponse webResponse = webRequest.GetResponse() as HttpWebResponse;

                // Get Response from remote server
                using (StreamReader reader = new StreamReader(webResponse.GetResponseStream()))
                {
                    company.ProjectsHref = JsonConvert.DeserializeObject<Company.CProjectHref[]>(reader.ReadToEnd());
                    foreach (Company.CProjectHref project in company.ProjectsHref)
                    {
                        if (project.projectInfo.name == projectName)
                        {
                            return project.Href;
                        }
                    }
                    Console.WriteLine("Error: The Project is not exsited.");
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Error: The connection is error.");
            }
            return string.Empty;
        }

        //#region Method_EncryptKeyWebServer
        //public static EncryptedKeyInfo[] GetEncryptKey(string clinetID, string assemblyName)
        //{
        //    try
        //    {
        //        StringBuilder connectStr = new StringBuilder(ConfigurationManager.AppSettings["EncryptKeyIP"]);
        //        HttpWebRequest webRequest = WebRequest.Create(connectStr.ToString()) as HttpWebRequest;                             // 用connectStr建立Http请求
        //        webRequest.Method = "Post";
        //        webRequest.ContentType = "application/json";
        //        string requestData = string.Format("{{\"kvs\":[{{\"clientId\":\"{0}\",\"assemblyName\":\"{1}\"}},{{\"clientId\":\"3010000444\",\"assemblyName\":\"{1}\"}}]}}", clinetID, assemblyName);
        //        byte[] encodingRequestData = Encoding.UTF8.GetBytes(requestData);
        //        webRequest.ContentLength = encodingRequestData.Length;
        //        Stream requestStream = webRequest.GetRequestStream();
        //        requestStream.Write(encodingRequestData, 0, encodingRequestData.Length);
        //        requestStream.Close();
        //        HttpWebResponse webResponse = webRequest.GetResponse() as HttpWebResponse;                                          // 把得到的WebResponse转换成HttpWebResponse
        //        using (StreamReader reader = new StreamReader(webResponse.GetResponseStream()))                                     // 读取HttpWebResponse的内容 注意！如果公司不存在，也会返回HttpWebResponse，但他的ContentLength是2
        //        {
        //            EncryptedKeyInfo[] EncryptedKeys = JsonConvert.DeserializeObject<EncryptedKeyInfo[]>(reader.ReadToEnd());

        //            Console.WriteLine("Info[200]: Find the EncryptKey: {0}.", EncryptedKeys);
        //            return EncryptedKeys;
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        Console.WriteLine("Error[200]: Can't find the EncryptKey.");
        //        return null;
        //    }
        //}
        
        //#endregion
    }
}