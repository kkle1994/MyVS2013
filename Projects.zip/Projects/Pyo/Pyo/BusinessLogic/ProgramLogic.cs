﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pyo.BusinessLogic
{
    /*
    public class Args
    {
        public string companyName { get; set; }
        public string projectName { get; set; }
        public string buildName { get; set; }
        public string productName { get; set; }
        public string typeName { get; set; }
        public string versionName { get; set; }
        public string userName { get; set; }
    }
     * */
    public class ProgramLogic
    {
        public static void ParseArgs(string[] args, Args cmd)
        {
            cmd.companyName = string.Empty;
            cmd.projectName = string.Empty;
            cmd.buildName = string.Empty;
            cmd.productName = string.Empty;
            cmd.typeName = string.Empty;
            cmd.userName = string.Empty;
            for (int i = 0; i < args.Length; i++)
            {
                switch (args[i])
                {
                    // 获取公司名称
                    case "-c":
                        if (args.Length >= i + 1) cmd.companyName = args[i + 1].Trim();
                        break;
                    // 获取项目名称
                    case "-p":
                        if (args.Length >= i + 1) cmd.projectName = args[i + 1].Trim();
                        break;
                    // 获取项目名称
                    case "-b":
                        if (args.Length >= i + 1) cmd.buildName = args[i + 1].Trim();
                        break;
                    // 取产品名称和版本
                    case "-P":
                        if (args.Length >= i + 1)
                        {
                            cmd.productName = args[i + 1].Trim().Split('/').ElementAtOrDefault(0);
                            cmd.typeName = args[i + 1].Trim().Split('/').ElementAtOrDefault(1);
                            cmd.versionName = args[i + 1].Trim().Split('/').ElementAtOrDefault(2);
                        }
                        break;
                    case "-a":
                        if (args.Length >= i + 1) cmd.userName = args[i + 1].Trim();
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
