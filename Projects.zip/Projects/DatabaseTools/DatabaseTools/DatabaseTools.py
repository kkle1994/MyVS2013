# -*-coding: utf-8 -*-
import pymongo
import pymssql
import sys
import json

def MongoCompanyInsert(name,ClientID,ID):
    db = conn[mgDB]
    print(conn.database_names())
    collection = db[mgCollection]
    account = collection;
    account.insert({"Name":name , "ClientId":ClientID, "_id":ID})

def MongoClear():
    db = conn[mgDB]
    print(conn.database_names())
    collection = db[mgCollection]
    collection.remove()

def __del__():
    conn.close()
    print('conn is closed')


mgPath = sys.argv[1]
mgPort = int(sys.argv[2])
mgDB = sys.argv[3]
mgCollection = sys.argv[4]

conn = pymongo.MongoClient(mgPath,mgPort)
MongoClear()
con = pymssql.connect(server='10.10.73.208:4399', user='sa', password='123456', database="PSPMS_Dev")
cursor = con.cursor()
cursor.execute('select * from company')
for row in cursor:
    MongoCompanyInsert(row[1],row[2],row[0])
    print(row)

con.close()
