﻿namespace ToolKits_For_GYH
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btm_CSVclear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btm_CSVclear
            // 
            this.btm_CSVclear.Location = new System.Drawing.Point(12, 12);
            this.btm_CSVclear.Name = "btm_CSVclear";
            this.btm_CSVclear.Size = new System.Drawing.Size(123, 33);
            this.btm_CSVclear.TabIndex = 0;
            this.btm_CSVclear.Text = "CSV逗号清理";
            this.btm_CSVclear.UseVisualStyleBackColor = true;
            this.btm_CSVclear.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 226);
            this.Controls.Add(this.btm_CSVclear);
            this.Name = "MainForm";
            this.Text = "欢迎使用GYH小工具";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btm_CSVclear;
    }
}

