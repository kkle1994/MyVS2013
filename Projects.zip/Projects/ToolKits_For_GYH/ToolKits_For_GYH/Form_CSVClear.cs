﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ToolKits_For_GYH
{
    public partial class Form_CSVClear : Form
    {
        public Form_CSVClear()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "CSV File (.csv)|*.csv";
            openFileDialog1.ShowDialog();
            textBox1.Text = openFileDialog1.FileName;
        }

        private void button2_Click(object sender, EventArgs e)
        {
                StreamReader sr = new StreamReader(textBox1.Text, Encoding.Default);
                String line;
                String all = "";
                while ((line = sr.ReadLine()) != null)
                {
                    for (int i = 0; i < line.Length; )
                    {
                        if (line[i].ToString() == "," && i == line.Length - 1)
                        {
                            i++;
                        }
                        else if (i == line.Length - 2)
                        {
                            i++;
                        }
                        else if (line[i].ToString() == "," && line[i + 1].ToString() == ",")
                        {
                            i++;
                        }
                        else
                        {
                            all += line[i].ToString();
                            i++;
                        }
                    }
                    all += "\r\n";
                }
                sr.Close();

                FileStream fs = new FileStream(textBox1.Text + "x", FileMode.Create);
                //获得字节数组
                byte[] data = System.Text.Encoding.Default.GetBytes(all);
                //开始写入
                fs.Write(data, 0, data.Length);
                //清空缓冲区、关闭流
                fs.Flush();
                fs.Close();

                MessageBox.Show("搞定~");
        }
    }
}
