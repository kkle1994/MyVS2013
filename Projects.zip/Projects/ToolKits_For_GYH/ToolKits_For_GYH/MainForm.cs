﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.IO;

namespace ToolKits_For_GYH
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form f1 = new Form_CSVClear();
            f1.Show();
            /*
            string Text1 = "123";
            string Text2 = "456asdfasdf";
            string Text3 = Text1 + "Encompass" + Text2;
            string x = EncryptString(Text1 + "Encompass" + Text2);
            MessageBox.Show(x);*/

        }
        string paddingStr = "*^c5Tred#w";//ConfigurationSettings.AppSettings["padding"];
        string cryptoKeyStr = "lR0jcllkr8Glv3/czEb8maf1TPRhPAcxvOS5K4o0I3YeQY/lqEMn36C9jjEYqWM2";
        string cryptoIVStr = "FBYwEot6Zbee/RMn3jU5fP9fiWda/DM23GkzaFfjFWQ=";
        public string password = "yzarc45?!grt89ghj";
        private byte[] cryptoKey, cryptoIV;
        private static string padding = "*^c5Tred#w";
        public string EncryptString(string src)//入口
        {
            cryptoKey = Convert.FromBase64String("iL8ZkH+UZBlmhAS5OnZn7HnPM9CQHwkbpOnkZzSyqes=");
            cryptoIV = Convert.FromBase64String("ZoQEuTp2Z+ydrVMafDOJOg==");
            byte[] toEncryptBuf = System.Text.Encoding.ASCII.GetBytes(src);
            string rk = Encoding.Unicode.GetString(cryptoKey);
            string r4 = Convert.ToBase64String(cryptoIV);
            byte[] encryptedBuf = encryptData(toEncryptBuf, cryptoKey, cryptoIV);
            return padding + Convert.ToBase64String(encryptedBuf);
        }

        private byte[] encryptData(byte[] dataToEncrypt, byte[] rijnKey, byte[] rijnIV)
        {
            RijndaelManaged rijn = new RijndaelManaged();
            ICryptoTransform encryptor = rijn.CreateEncryptor(rijnKey, rijnIV);
            MemoryStream msEncrypt = new MemoryStream();
            CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write);
            csEncrypt.Write(dataToEncrypt, 0, dataToEncrypt.Length);
            csEncrypt.FlushFinalBlock();
            return msEncrypt.ToArray();
        }
    }
}
