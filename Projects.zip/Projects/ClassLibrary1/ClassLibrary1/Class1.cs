﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DBOperate
{
    public class DBOperate
    {
        //获取连接
        public SqlConnection DBOperate_getcon()
        {
            String M_str_sqlcon = "Data Source=(LocalDB)\\v11.0;AttachDbFilename=\"C:\\Users\\Administrator\\Desktop\\数据表\\db_Hotel .mdf\";Integrated Security=True;Connect Timeout=30";
            //M_str_sqlcon = Settings.Default.db_HotelConnectionString;
            SqlConnection con = new SqlConnection(M_str_sqlcon);
            return con;
        }
        //执行SQL语句
        public bool DBOperate_opCom(String P_str_sqlstr)
        {
            bool ool = false;
            SqlConnection con = this.DBOperate_getcon();
            con.Open();
            SqlCommand com = new SqlCommand(P_str_sqlstr, con);
            if (com.ExecuteNonQuery() > 0)
                ool = true;
            com.Dispose();
            con.Close();
            con.Dispose();
            return ool;
        }
        //获取DATASET
        public DataSet DBOperate_getDs(String P_str_sqlstr, String P_str_table)
        {
            DataSet ds = new DataSet();
            SqlConnection con = this.DBOperate_getcon();
            SqlDataAdapter adapter = new SqlDataAdapter(P_str_sqlstr, con);
            con.Open();
            adapter.Fill(ds, P_str_table);
            return ds;
        }
        //获取SqlDataReader
        public SqlDataReader DBOperate_getReader(String P_str_sqlstr)
        {
            SqlConnection con = this.DBOperate_getcon();
            SqlCommand com = new SqlCommand(P_str_sqlstr, con);
            con.Open();
            SqlDataReader reader = com.ExecuteReader(CommandBehavior.CloseConnection);
            return reader;
        }
        //插入
        public bool DBOperate_Insert(String[,] _DBOperateInsertStr, String _DBOperateTableName)
        {
            int _DBOperateAcount = _DBOperateInsertStr.Length / 2;   //要插入的列名数量
            if (_DBOperateAcount == 1)
                return DBOperate_opCom("INSERT INTO " + _DBOperateTableName + "(" + _DBOperateInsertStr[0, 0] + ") VALUES('" + _DBOperateInsertStr[1, 0] + "')");
            else if (_DBOperateAcount > 1)
            {
                String _DBOperateStr1 = _DBOperateInsertStr[0, 0];     //插入语句的列名
                String _DBOperateStr2 = "'" + _DBOperateInsertStr[1, 0] + "'";     //插入语句列名对应的值
                for (int i = 1; i < _DBOperateAcount; i++)
                    _DBOperateStr1 += "," + _DBOperateInsertStr[0, i];
                for (int j = 1; j < _DBOperateAcount; j++)
                    _DBOperateStr2 += ",'" + _DBOperateInsertStr[1, j] + "'";
                return DBOperate_opCom("INSERT INTO " + _DBOperateTableName + "(" + _DBOperateStr1 + ") Values(" + _DBOperateStr2 + ")");
            }
            else
                return false;

        }
        //修改
        public bool DBOperate_Update(String[,] _DBOperateUpdateStr, String _DBOperateTableName, String _DBOperateCondition)
        {
            int _DBOperateAcount = _DBOperateUpdateStr.Length / 2;                  //要修改的列名数量
            if (_DBOperateAcount <= 0)
                return false;
            else
            {
                String _CommandText = "UPDATE " + _DBOperateTableName + " SET ";    //更新的SQL字符串
                for (int i = 0; i < _DBOperateAcount - 1; i++)
                    _CommandText += _DBOperateUpdateStr[0, i] + "='" + _DBOperateUpdateStr[1, i] + "',";

                _CommandText = _CommandText + _DBOperateUpdateStr[0, _DBOperateAcount - 1] + "='" + _DBOperateUpdateStr[1, _DBOperateAcount - 1] + "'" + " WHERE " + _DBOperateCondition;
                return DBOperate_opCom(_CommandText);
            }
        }
        //删除
        public bool DBOperate_Delete(String _DBOperateDeleteStr, String _DBOperateTableName)
        {
            return DBOperate_opCom("DELETE FROM " + _DBOperateTableName + " WHERE " + _DBOperateDeleteStr);
        }
        //查询，并返回第一行第一列
        public Object DBOperate_Scalar(String _DBOperateSelectStr)
        {
            SqlConnection con = this.DBOperate_getcon();
            SqlCommand com = new SqlCommand(_DBOperateSelectStr, con);
            con.Open();
            return com.ExecuteScalar();

        }

    }
}
